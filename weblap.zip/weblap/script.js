 

function playPause() { 
    var myVideo = document.getElementById("video1");
  if (myVideo.paused) 
    myVideo.play(); 
  else 
    myVideo.pause(); 
} 

 function teljes(){
  var video = document.getElementById("video1");
  if (video.requestFullscreen) {
    video.requestFullscreen();
  } else if (video.webkitRequestFullscreen) {
    video.webkitRequestFullscreen();
  } else if (video.mozRequestFullScreen) {
    video.mozRequestFullScreen();
  } else if (video.msRequestFullscreen) {
    video.msRequestFullscreen();
  }
}

function playPause2() { 
  var myVideo = document.getElementById("video2");
if (myVideo.paused) 
  myVideo.play(); 
else 
  myVideo.pause(); 
} 

function teljes2(){
var video = document.getElementById("video2");
if (video.requestFullscreen) {
  video.requestFullscreen();
} else if (video.webkitRequestFullscreen) {
  video.webkitRequestFullscreen();
} else if (video.mozRequestFullScreen) {
  video.mozRequestFullScreen();
} else if (video.msRequestFullscreen) {
  video.msRequestFullscreen();
}
}

 function hatter(){
  var element = document.getElementById("felso");
    element.onmouseover = function() {
        element.style.backgroundColor = "red";
    }
    element.onmouseout = function() {
        element.style.backgroundColor = "";
    }
  }
    function nagyito (name) {
    var heading = document.getElementById(name);
    heading.onmouseover = function() {
        heading.style.fontSize = "50px";
    }
    heading.onmouseout = function() {
        heading.style.fontSize = "";
    }
  } 
